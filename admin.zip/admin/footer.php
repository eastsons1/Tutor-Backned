<div style="
    background: #000;
    text-align: center;
    border-top: 2px solid green;
    color: #fff;
    padding: 6px 0 6px 0;
">
    <div>Copyright © 2021 Sarabella All Rights Reserved.</div>
</div>




<!-- Jquery Core Js --> 
<script src="assets_n/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js ( jquery.v3.2.1, Bootstrap4 js) --> 
<script src="assets_n/bundles/vendorscripts.bundle.js"></script> <!-- slimscroll, waves Scripts Plugin Js -->

<script src="assets_n/bundles/morrisscripts.bundle.js"></script><!-- Morris Plugin Js -->
<script src="assets_n/bundles/jvectormap.bundle.js"></script> <!-- JVectorMap Plugin Js -->
<script src="assets_n/bundles/knob.bundle.js"></script> <!-- Jquery Knob Plugin Js -->
<script src="assets_n/bundles/sparkline.bundle.js"></script> <!-- Sparkline Plugin Js -->

<script src="assets_n/bundles/mainscripts.bundle.js"></script>
<script src="assets_n/js/pages/index.js"></script>