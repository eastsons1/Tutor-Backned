<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");

require_once("config.php");
//require_once("dbcontroller.php");
header('content-type:application/json');
   


  $user_login_id = $_POST['user_login_id'];
  
  
  
  if($user_login_id != "" )
  {
	  $check = $conn->query("SELECT * FROM user_info WHERE user_id = '".$user_login_id."' ");
  
	  if(mysqli_num_rows($check)>0)
	  {
		  
		  ////booked_tutor
		  $booked_tutor = $conn->query("DELETE FROM booked_tutor WHERE booked_by_user_id = '".$user_login_id."' ");
			
			////chatrooms
		  $chatrooms = $conn->query("DELETE FROM chatrooms WHERE loggedIn_user_id = '".$user_login_id."' ");
			
			////chat_users_details
		  $chat_users_details = $conn->query("DELETE FROM chat_users_details WHERE tutor_id = '".$user_login_id."' ");
			
			////complete_user_profile_history_academy
		  $complete_user_profile_history_academy = $conn->query("DELETE FROM complete_user_profile_history_academy WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_history_academy_result
		  $complete_user_profile_history_academy_result = $conn->query("DELETE FROM complete_user_profile_history_academy_result WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_qualification_academy_result
		  $complete_user_profile_qualification_academy_result = $conn->query("DELETE FROM complete_user_profile_qualification_academy_result WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_tutoring_admission_level
		  $complete_user_profile_tutoring_admission_level = $conn->query("DELETE FROM complete_user_profile_tutoring_admission_level WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_tutoring_admission_stream
		  $complete_user_profile_tutoring_admission_stream = $conn->query("DELETE FROM complete_user_profile_tutoring_admission_stream WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_tutoring_detail
		  $complete_user_profile_tutoring_detail = $conn->query("DELETE FROM complete_user_profile_tutoring_detail WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_tutoring_grade_detail
		  $complete_user_profile_tutoring_grade_detail = $conn->query("DELETE FROM complete_user_profile_tutoring_grade_detail WHERE user_id = '".$user_login_id."' ");
			
			////complete_user_profile_tutoring_tutoring_subjects_detail
		  $complete_user_profile_tutoring_tutoring_subjects_detail = $conn->query("DELETE FROM complete_user_profile_tutoring_tutoring_subjects_detail WHERE user_id = '".$user_login_id."' ");
			
			////favourite_student_post_requirement_by_tutor
		  $favourite_student_post_requirement_by_tutor = $conn->query("DELETE FROM favourite_student_post_requirement_by_tutor WHERE tutor_login_id = '".$user_login_id."' ");
			
			////favourite_tutor_by_student
		  $favourite_tutor_by_student = $conn->query("DELETE FROM favourite_tutor_by_student WHERE tutor_id = '".$user_login_id."' ");
			
			////post_rating
		  $post_rating = $conn->query("DELETE FROM post_rating WHERE userid = '".$user_login_id."' ");
			
			
			
			////student_post_requirements_Applied_by_tutor
		  $student_post_requirements_Applied_by_tutor = $conn->query("DELETE FROM student_post_requirements_Applied_by_tutor WHERE tutor_login_id = '".$user_login_id."' ");
			
			////student_post_requirements_Favourite_Assigned
		  $student_post_requirements_Favourite_Assigned = $conn->query("DELETE FROM student_post_requirements_Favourite_Assigned WHERE tutor_login_id = '".$user_login_id."' ");
			
			////student_post_requirement_amount_negotiate
		  $student_post_requirement_amount_negotiate = $conn->query("DELETE FROM student_post_requirement_amount_negotiate WHERE tutor_login_id = '".$user_login_id."' ");
		
		
		
			////tbl_book_tutor_by_student
		  $tbl_book_tutor_by_student = $conn->query("DELETE FROM tbl_book_tutor_by_student WHERE tutor_id = '".$user_login_id."' ");
			
			////tbl_chatrooms_acceptance
		  $tbl_chatrooms_acceptance = $conn->query("DELETE FROM tbl_chatrooms_acceptance WHERE loggedIn_user_id = '".$user_login_id."' ");
			
		   ////tbl_payment
		  $tbl_payment = $conn->query("DELETE FROM tbl_payment WHERE logged_in_user_id = '".$user_login_id."' ");
				
			////tbl_rating
		  $tbl_rating = $conn->query("DELETE FROM tbl_rating WHERE tutor_id = '".$user_login_id."' ");
				
			
			////tbl_temp_documents
		  $tbl_temp_documents = $conn->query("DELETE FROM tbl_temp_documents WHERE user_id = '".$user_login_id."' ");
				
			////tbl_user_documents
		  $tbl_user_documents = $conn->query("DELETE FROM tbl_user_documents WHERE user_id = '".$user_login_id."' ");
					
			////tbl_user_order_request_docs
		  $tbl_user_order_request_docs = $conn->query("DELETE FROM tbl_user_order_request_docs WHERE user_id = '".$user_login_id."' ");
			
			////tbl_user_suspended
		  $tbl_user_suspended = $conn->query("DELETE FROM tbl_user_suspended WHERE user_id = '".$user_login_id."' ");

			////token_table
		  $token_table = $conn->query("DELETE FROM token_table WHERE user_id = '".$user_login_id."' ");

			////tutor_booking_process
		  $tutor_booking_process = $conn->query("DELETE FROM tutor_booking_process WHERE tutor_id = '".$user_login_id."' ");





			////tutor_booking_process
			$get_tbpid = $conn->query("SELECT * FROM tutor_booking_process");
			
			while($get_tbpid_Data = mysqli_fetch_array($get_tbpid))
			{
				$tutor_booking_process_Level_Grade_Subjects = $conn->query("DELETE FROM tutor_booking_process_Level_Grade_Subjects WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_Schedules_Slot_Time = $conn->query("DELETE FROM tutor_booking_process_Schedules_Slot_Time WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_streams = $conn->query("DELETE FROM tutor_booking_process_streams WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_StudentSubjects = $conn->query("DELETE FROM tutor_booking_process_StudentSubjects WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_TutorQualification = $conn->query("DELETE FROM tutor_booking_process_TutorQualification WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_TutorSchedule = $conn->query("DELETE FROM tutor_booking_process_TutorSchedule WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				$tutor_booking_process_TutorSlotsTime = $conn->query("DELETE FROM tutor_booking_process_TutorSlotsTime WHERE tutor_booking_process_id = '".$get_tbpid_Data['tutor_booking_process_id']."' ");
				
				
			}
			
			
			
			
			$tutor_booking_process = $conn->query("DELETE FROM tutor_booking_process WHERE tutor_id = '".$user_login_id."' ");

			$tutor_qualification_subject_grade = $conn->query("DELETE FROM tutor_qualification_subject_grade WHERE user_id = '".$user_login_id."' ");

			$tutor_totoring_grade = $conn->query("DELETE FROM tutor_totoring_grade WHERE user_id = '".$user_login_id."' ");

			$tutor_totoring_levels = $conn->query("DELETE FROM tutor_totoring_levels WHERE user_id = '".$user_login_id."' ");

			$tutor_totoring_stream = $conn->query("DELETE FROM tutor_totoring_stream WHERE user_id = '".$user_login_id."' ");

			$tutor_tutorial_subjects = $conn->query("DELETE FROM tutor_tutorial_subjects WHERE user_id = '".$user_login_id."' ");


			 $user_info_img     = $conn->query("select * from user_info where user_id = '".$user_login_id."' ");
			$user_info_img_res = mysqli_fetch_array($user_info_img);
			$fetch1      = $user_info_img_res['profile_image'];
			@unlink("../../UPLOAD_file/".$fetch1 );

			$user_info = $conn->query("DELETE FROM user_info WHERE user_id = '".$user_login_id."' ");

			$user_info_device_token = $conn->query("DELETE FROM user_info_device_token WHERE user_id = '".$user_login_id."' ");

			$user_info_temp = $conn->query("DELETE FROM user_info_temp WHERE user_id = '".$user_login_id."' ");

			$user_student_info = $conn->query("DELETE FROM user_student_info WHERE user_id = '".$user_login_id."' ");
			
			
			$user_tutor_info_img     = $conn->query("select * from user_tutor_info where user_id = '".$user_login_id."' ");
			$user_tutor_info_img_res = mysqli_fetch_array($user_tutor_info_img);
			$fetch2      = $user_tutor_info_img_res['profile_image'];
			@unlink("../../UPLOAD_file/".$fetch2 );
			
			
			
			$user_tutor_info = $conn->query("DELETE FROM user_tutor_info WHERE user_id = '".$user_login_id."' ");

			$del = $conn->query("DELETE FROM `user_info` WHERE user_id = '".$user_login_id."' " );
		  
		 
		  if($del)
		  {
			  $resultData = array('status' => true, 'message' => 'Account Deleted Successfully.');
		  }
		  else
		  {
			  $resultData = array('status' => false, 'message' => 'Execution Error' );
		  }
	  
	  }
	else
	{
		$resultData = array('status' => false, 'message' => 'Record Not Found.');
	}	
  
  }
  else
  {
	  $resultData = array('status' => false, 'message' => 'User Login Id can not blank.');
  }
  
  
  echo json_encode($resultData);
  

?>